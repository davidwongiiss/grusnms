package com.grus.nms.dao;

import com.grus.nms.pojo.GbeValues;

public interface IGbeValuesDAO {

	public boolean doCreateForGbeDayValues(GbeValues gbe) throws Exception;
}
