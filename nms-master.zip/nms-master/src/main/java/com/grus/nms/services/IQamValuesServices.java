package com.grus.nms.services;

import com.grus.nms.pojo.QamValues;

public interface IQamValuesServices {

	public boolean insertQamValuesForDay(QamValues qam) throws Exception;
}
