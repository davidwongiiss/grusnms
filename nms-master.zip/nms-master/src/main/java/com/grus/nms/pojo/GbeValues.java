package com.grus.nms.pojo;

import java.sql.Timestamp;

public class GbeValues {

	private String nodeId;
	private Integer numberOfServices1;
	private Integer numberOfServices2;
	private Integer numberOfServices3;
	private Integer numberOfServices4;
	private Integer numberOfServices5;
	private Integer numberOfServices6;
	private Integer numberOfServices7;
	private Integer numberOfServices8;
	
	private Integer multicastBitrate1;
	private Integer multicastBitrate2;
	private Integer multicastBitrate3;
	private Integer multicastBitrate4;
	private Integer multicastBitrate5;
	private Integer multicastBitrate6;
	private Integer multicastBitrate7;
	private Integer multicastBitrate8;
	
	private Timestamp createTime;
	
	
	public Timestamp getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}
	public String getNodeId() {
		return nodeId;
	}
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	public Integer getNumberOfServices1() {
		return numberOfServices1;
	}
	public void setNumberOfServices1(Integer numberOfServices1) {
		this.numberOfServices1 = numberOfServices1;
	}
	public Integer getNumberOfServices2() {
		return numberOfServices2;
	}
	public void setNumberOfServices2(Integer numberOfServices2) {
		this.numberOfServices2 = numberOfServices2;
	}
	public Integer getNumberOfServices3() {
		return numberOfServices3;
	}
	public void setNumberOfServices3(Integer numberOfServices3) {
		this.numberOfServices3 = numberOfServices3;
	}
	public Integer getNumberOfServices4() {
		return numberOfServices4;
	}
	public void setNumberOfServices4(Integer numberOfServices4) {
		this.numberOfServices4 = numberOfServices4;
	}
	public Integer getNumberOfServices5() {
		return numberOfServices5;
	}
	public void setNumberOfServices5(Integer numberOfServices5) {
		this.numberOfServices5 = numberOfServices5;
	}
	public Integer getNumberOfServices6() {
		return numberOfServices6;
	}
	public void setNumberOfServices6(Integer numberOfServices6) {
		this.numberOfServices6 = numberOfServices6;
	}
	public Integer getNumberOfServices7() {
		return numberOfServices7;
	}
	public void setNumberOfServices7(Integer numberOfServices7) {
		this.numberOfServices7 = numberOfServices7;
	}
	public Integer getNumberOfServices8() {
		return numberOfServices8;
	}
	public void setNumberOfServices8(Integer numberOfServices8) {
		this.numberOfServices8 = numberOfServices8;
	}
	public Integer getMulticastBitrate1() {
		return multicastBitrate1;
	}
	public void setMulticastBitrate1(Integer multicastBitrate1) {
		this.multicastBitrate1 = multicastBitrate1;
	}
	public Integer getMulticastBitrate2() {
		return multicastBitrate2;
	}
	public void setMulticastBitrate2(Integer multicastBitrate2) {
		this.multicastBitrate2 = multicastBitrate2;
	}
	public Integer getMulticastBitrate3() {
		return multicastBitrate3;
	}
	public void setMulticastBitrate3(Integer multicastBitrate3) {
		this.multicastBitrate3 = multicastBitrate3;
	}
	public Integer getMulticastBitrate4() {
		return multicastBitrate4;
	}
	public void setMulticastBitrate4(Integer multicastBitrate4) {
		this.multicastBitrate4 = multicastBitrate4;
	}
	public Integer getMulticastBitrate5() {
		return multicastBitrate5;
	}
	public void setMulticastBitrate5(Integer multicastBitrate5) {
		this.multicastBitrate5 = multicastBitrate5;
	}
	public Integer getMulticastBitrate6() {
		return multicastBitrate6;
	}
	public void setMulticastBitrate6(Integer multicastBitrate6) {
		this.multicastBitrate6 = multicastBitrate6;
	}
	public Integer getMulticastBitrate7() {
		return multicastBitrate7;
	}
	public void setMulticastBitrate7(Integer multicastBitrate7) {
		this.multicastBitrate7 = multicastBitrate7;
	}
	public Integer getMulticastBitrate8() {
		return multicastBitrate8;
	}
	public void setMulticastBitrate8(Integer multicastBitrate8) {
		this.multicastBitrate8 = multicastBitrate8;
	}
	
	
	
}
