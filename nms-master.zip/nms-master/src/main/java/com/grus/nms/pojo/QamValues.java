package com.grus.nms.pojo;

import java.sql.Timestamp;

public class QamValues {

	private String nodeId;
	private Integer qam1;
	private Integer qam2;
	private Integer qam3;
	private Integer qam4;
	private Integer qam5;
	private Integer qam6;
	private Integer qam7;
	private Integer qam8;
	private Integer qam9;
	private Integer qam10;
	private Integer qam11;
	private Integer qam12;
	private Integer qam13;
	private Integer qam14;
	private Integer qam15;
	private Integer qam16;
	private Integer qam17;
	private Integer qam18;
	
	private Integer bitrate1;
	private Integer bitrate2;
	private Integer bitrate3;
	private Integer bitrate4;
	private Integer bitrate5;
	private Integer bitrate6;
	private Integer bitrate7;
	private Integer bitrate8;
	private Integer bitrate9;
	private Integer bitrate10;
	private Integer bitrate11;
	private Integer bitrate12;
	private Integer bitrate13;
	private Integer bitrate14;
	private Integer bitrate15;
	private Integer bitrate16;
	private Integer bitrate17;
	private Integer bitrate18;
	
	private Integer numOfServices1;
	private Integer numOfServices2;
	private Integer numOfServices3;
	private Integer numOfServices4;
	private Integer numOfServices5;
	private Integer numOfServices6;
	private Integer numOfServices7;
	private Integer numOfServices8;
	private Integer numOfServices9;
	private Integer numOfServices10;
	private Integer numOfServices11;
	private Integer numOfServices12;
	private Integer numOfServices13;
	private Integer numOfServices14;
	private Integer numOfServices15;
	private Integer numOfServices16;
	private Integer numOfServices17;
	private Integer numOfServices18;
	
	private Integer blade;
	private Timestamp createTime;
	public Integer getBlade() {
		return blade;
	}


	public void setBlade(Integer blade) {
		this.blade = blade;
	}


	


	public String getNodeId() {
		return nodeId;
	}


	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}


	public Integer getQam1() {
		return qam1;
	}


	public void setQam1(Integer qam1) {
		this.qam1 = qam1;
	}


	public Integer getQam2() {
		return qam2;
	}


	public void setQam2(Integer qam2) {
		this.qam2 = qam2;
	}


	public Integer getQam3() {
		return qam3;
	}


	public void setQam3(Integer qam3) {
		this.qam3 = qam3;
	}


	public Integer getQam4() {
		return qam4;
	}


	public void setQam4(Integer qam4) {
		this.qam4 = qam4;
	}


	public Integer getQam5() {
		return qam5;
	}


	public void setQam5(Integer qam5) {
		this.qam5 = qam5;
	}


	public Integer getQam6() {
		return qam6;
	}


	public void setQam6(Integer qam6) {
		this.qam6 = qam6;
	}


	public Integer getQam7() {
		return qam7;
	}


	public void setQam7(Integer qam7) {
		this.qam7 = qam7;
	}


	public Integer getQam8() {
		return qam8;
	}


	public void setQam8(Integer qam8) {
		this.qam8 = qam8;
	}


	public Integer getQam9() {
		return qam9;
	}


	public void setQam9(Integer qam9) {
		this.qam9 = qam9;
	}


	public Integer getQam10() {
		return qam10;
	}


	public void setQam10(Integer qam10) {
		this.qam10 = qam10;
	}


	public Integer getQam11() {
		return qam11;
	}


	public void setQam11(Integer qam11) {
		this.qam11 = qam11;
	}


	public Integer getQam12() {
		return qam12;
	}


	public void setQam12(Integer qam12) {
		this.qam12 = qam12;
	}


	public Integer getQam13() {
		return qam13;
	}


	public void setQam13(Integer qam13) {
		this.qam13 = qam13;
	}


	public Integer getQam14() {
		return qam14;
	}


	public void setQam14(Integer qam14) {
		this.qam14 = qam14;
	}


	public Integer getQam15() {
		return qam15;
	}


	public void setQam15(Integer qam15) {
		this.qam15 = qam15;
	}


	public Integer getQam16() {
		return qam16;
	}


	public void setQam16(Integer qam16) {
		this.qam16 = qam16;
	}


	public Integer getQam17() {
		return qam17;
	}


	public void setQam17(Integer qam17) {
		this.qam17 = qam17;
	}


	public Integer getQam18() {
		return qam18;
	}


	public void setQam18(Integer qam18) {
		this.qam18 = qam18;
	}


	public Integer getBitrate1() {
		return bitrate1;
	}


	public void setBitrate1(Integer bitrate1) {
		this.bitrate1 = bitrate1;
	}


	public Integer getBitrate2() {
		return bitrate2;
	}


	public void setBitrate2(Integer bitrate2) {
		this.bitrate2 = bitrate2;
	}


	public Integer getBitrate3() {
		return bitrate3;
	}


	public void setBitrate3(Integer bitrate3) {
		this.bitrate3 = bitrate3;
	}


	public Integer getBitrate4() {
		return bitrate4;
	}


	public void setBitrate4(Integer bitrate4) {
		this.bitrate4 = bitrate4;
	}


	public Integer getBitrate5() {
		return bitrate5;
	}


	public void setBitrate5(Integer bitrate5) {
		this.bitrate5 = bitrate5;
	}


	public Integer getBitrate6() {
		return bitrate6;
	}


	public void setBitrate6(Integer bitrate6) {
		this.bitrate6 = bitrate6;
	}


	public Integer getBitrate7() {
		return bitrate7;
	}


	public void setBitrate7(Integer bitrate7) {
		this.bitrate7 = bitrate7;
	}


	public Integer getBitrate8() {
		return bitrate8;
	}


	public void setBitrate8(Integer bitrate8) {
		this.bitrate8 = bitrate8;
	}


	public Integer getBitrate9() {
		return bitrate9;
	}


	public void setBitrate9(Integer bitrate9) {
		this.bitrate9 = bitrate9;
	}


	public Integer getBitrate10() {
		return bitrate10;
	}


	public void setBitrate10(Integer bitrate10) {
		this.bitrate10 = bitrate10;
	}


	public Integer getBitrate11() {
		return bitrate11;
	}


	public void setBitrate11(Integer bitrate11) {
		this.bitrate11 = bitrate11;
	}


	public Integer getBitrate12() {
		return bitrate12;
	}


	public void setBitrate12(Integer bitrate12) {
		this.bitrate12 = bitrate12;
	}


	public Integer getBitrate13() {
		return bitrate13;
	}


	public void setBitrate13(Integer bitrate13) {
		this.bitrate13 = bitrate13;
	}


	public Integer getBitrate14() {
		return bitrate14;
	}


	public void setBitrate14(Integer bitrate14) {
		this.bitrate14 = bitrate14;
	}


	public Integer getBitrate15() {
		return bitrate15;
	}


	public void setBitrate15(Integer bitrate15) {
		this.bitrate15 = bitrate15;
	}


	public Integer getBitrate16() {
		return bitrate16;
	}


	public void setBitrate16(Integer bitrate16) {
		this.bitrate16 = bitrate16;
	}


	public Integer getBitrate17() {
		return bitrate17;
	}


	public void setBitrate17(Integer bitrate17) {
		this.bitrate17 = bitrate17;
	}


	public Integer getBitrate18() {
		return bitrate18;
	}


	public void setBitrate18(Integer bitrate18) {
		this.bitrate18 = bitrate18;
	}


	public Integer getNumOfServices1() {
		return numOfServices1;
	}


	public void setNumOfServices1(Integer numOfServices1) {
		this.numOfServices1 = numOfServices1;
	}


	public Integer getNumOfServices2() {
		return numOfServices2;
	}


	public void setNumOfServices2(Integer numOfServices2) {
		this.numOfServices2 = numOfServices2;
	}


	public Integer getNumOfServices3() {
		return numOfServices3;
	}


	public void setNumOfServices3(Integer numOfServices3) {
		this.numOfServices3 = numOfServices3;
	}


	public Integer getNumOfServices4() {
		return numOfServices4;
	}


	public void setNumOfServices4(Integer numOfServices4) {
		this.numOfServices4 = numOfServices4;
	}


	public Integer getNumOfServices5() {
		return numOfServices5;
	}


	public void setNumOfServices5(Integer numOfServices5) {
		this.numOfServices5 = numOfServices5;
	}


	public Integer getNumOfServices6() {
		return numOfServices6;
	}


	public void setNumOfServices6(Integer numOfServices6) {
		this.numOfServices6 = numOfServices6;
	}


	public Integer getNumOfServices7() {
		return numOfServices7;
	}


	public void setNumOfServices7(Integer numOfServices7) {
		this.numOfServices7 = numOfServices7;
	}


	public Integer getNumOfServices8() {
		return numOfServices8;
	}


	public void setNumOfServices8(Integer numOfServices8) {
		this.numOfServices8 = numOfServices8;
	}


	public Integer getNumOfServices9() {
		return numOfServices9;
	}


	public void setNumOfServices9(Integer numOfServices9) {
		this.numOfServices9 = numOfServices9;
	}


	public Integer getNumOfServices10() {
		return numOfServices10;
	}


	public void setNumOfServices10(Integer numOfServices10) {
		this.numOfServices10 = numOfServices10;
	}


	public Integer getNumOfServices11() {
		return numOfServices11;
	}


	public void setNumOfServices11(Integer numOfServices11) {
		this.numOfServices11 = numOfServices11;
	}


	public Integer getNumOfServices12() {
		return numOfServices12;
	}


	public void setNumOfServices12(Integer numOfServices12) {
		this.numOfServices12 = numOfServices12;
	}


	public Integer getNumOfServices13() {
		return numOfServices13;
	}


	public void setNumOfServices13(Integer numOfServices13) {
		this.numOfServices13 = numOfServices13;
	}


	public Integer getNumOfServices14() {
		return numOfServices14;
	}


	public void setNumOfServices14(Integer numOfServices14) {
		this.numOfServices14 = numOfServices14;
	}


	public Integer getNumOfServices15() {
		return numOfServices15;
	}


	public void setNumOfServices15(Integer numOfServices15) {
		this.numOfServices15 = numOfServices15;
	}


	public Integer getNumOfServices16() {
		return numOfServices16;
	}


	public void setNumOfServices16(Integer numOfServices16) {
		this.numOfServices16 = numOfServices16;
	}


	public Integer getNumOfServices17() {
		return numOfServices17;
	}


	public void setNumOfServices17(Integer numOfServices17) {
		this.numOfServices17 = numOfServices17;
	}


	public Integer getNumOfServices18() {
		return numOfServices18;
	}


	public void setNumOfServices18(Integer numOfServices18) {
		this.numOfServices18 = numOfServices18;
	}


	public Timestamp getCreateTime() {
		return createTime;
	}


	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}
	
	
	
}
