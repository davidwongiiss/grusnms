package com.grus.nms.services;

import com.grus.nms.pojo.GbeValues;

public interface IGbeValuesServices {

	public boolean insertGbeValuesForGbeDay(GbeValues gbe) throws Exception;
}
